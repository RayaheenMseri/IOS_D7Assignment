//
//  Day7_AssignmentApp.swift
//  Day7_Assignment
//
//  Created by Taibah Valley Academy on 10/09/1446 AH.
//

import SwiftUI

@main
struct Day7_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
