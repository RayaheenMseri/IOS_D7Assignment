//
//  TaskViewModel.swift
//  Day7_Assignment
//
//  Created by Taibah Valley Academy on 10/09/1446 AH.
//

import SwiftUI

class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = [
        Task(title: "Study", isCompleted: true),
        Task(title: "HomeWork", isCompleted: false),
        Task(title: "WorkOut", isCompleted: true),
        Task(title: "Cleaning", isCompleted: false),
        Task(title: "Shopping", isCompleted: true),
        Task(title: "Reading", isCompleted: false),
    ]
    
    //add task
    func addTask(task: Task) {
        tasks.append(task)
    }

    // delete task
    func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
    
    // sort task the complete task go to buttom of the lsit
    func sortTasks() {
        tasks.sort { (task1: Task, task2: Task) -> Bool in
            return !task1.isCompleted && task2.isCompleted
        }
    }
    
    // update the completeion value when the user complete a task
    func updateTaskCompletion(task: Task, isCompleted: Bool) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted = isCompleted
        }
    }
}
