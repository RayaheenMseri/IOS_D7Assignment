//
//  Task.swift
//  Day7_Assignment
//
//  Created by Taibah Valley Academy on 10/09/1446 AH.
//

import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    let title: String
    var isCompleted: Bool
}
