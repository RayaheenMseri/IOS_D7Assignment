//
//  AddTaskView.swift
//  Day7_Assignment
//
//  Created by Taibah Valley Academy on 10/09/1446 AH.
//


import SwiftUI

struct AddUserView: View {
    @Environment(\.dismiss) private var dismiss // Environment property to dismiss the current view when adding a task
    @State var title: String = "" // State variable to hold the input title for a new task
    @ObservedObject var viewModel: TaskViewModel // Observed view model to manage the task data
    
    var body: some View {
        VStack {
            // Display the title of the view (Add New Task)
            Text("Add New Task")
                .font(.headline)
            
            // Form to input the task details
            Form {
                HStack {
                    // Label for the title field
                    Text("Title :")
                    
                    // TextField to input the task title
                    TextField("title", text: $title) // Binding the title state variable to the TextField
                        .padding()
                        .background(Color.gray.opacity(0.2)) // Light gray background color
                        .cornerRadius(5)
                }
            }
                .scrollContentBackground(.hidden) // Hide background behind the scrollable content of the form
                
                // Add button to create a new task
                Button("Add") {
                    // Call the view model's addTask method to add a new task
                    viewModel.addTask(task: Task(title: title, isCompleted: false)) // Create a new task with title and default 'isCompleted' value
                    dismiss() // Dismiss the current view after adding the task
                }
                .frame(width: 150)
                .padding()
                .background(Color("CustomColors")) // Custom background color for the button
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .frame(width: 400, height: 220, alignment: .center) // Set the size and alignment of the view
        }
    }


#Preview {
    AddUserView(viewModel: TaskViewModel())
}
