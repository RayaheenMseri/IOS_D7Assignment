//
//  ContentView.swift
//  Day7_Assignment
//
//  Created by Taibah Valley Academy on 10/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var isDarkMode = false   // State variable to manage Dark Mode toggle
    @State private var newTask = ""         // State variable to hold the input for a new task
    @StateObject var taskModel = TaskViewModel() // ViewModel to manage the tasks, marked with @StateObject for ownership

    var body: some View {
        NavigationView {
            VStack(spacing: 2) {  // Vertical stack with minimal spacing between views
                ZStack(alignment:.bottomTrailing){ // ZStack to overlay UI elements, aligned to the bottom right
                    // Check if there are no tasks in the task model
                    if taskModel.tasks.isEmpty {
                        Text("No Tasks Found")
                            .foregroundColor(Color("CustomColors"))  // Custom color for the message
                    } else {
                        // Display tasks in a list if there are any tasks
                        List {
                            ForEach(taskModel.tasks) { task in
                                HStack {
                                    // Task title displayed in a row with some padding
                                    Text(task.title)
                                        .font(.body)
                                        .foregroundColor(.primary)
                                        .frame(width: 210, alignment: .leading)
                                        .padding()

                                    Spacer() // Spacer to push the checkmark button to the right

                                    // Button to toggle the completion status of the task
                                    Button(action: {
                                        taskModel.updateTaskCompletion(task: task, isCompleted: !task.isCompleted)
                                    }) {
                                        // Display either a checked or unchecked box based on the task's completion state
                                        Image(systemName: task.isCompleted ? "checkmark.square.fill" : "square")
                                            .foregroundColor(task.isCompleted ? Color("CustomColors") : Color("CustomColors"))
                                            .frame(width: 30, height: 30)
                                    }
                                }
                                .background(.gray.opacity(0.1))
                                .cornerRadius(10)
                            }
                            .onDelete(perform: taskModel.deleteTask) // Allow swipe-to-delete gesture on tasks
                        }
                        .frame(width:.infinity) // Ensure the list takes up full width
                        .navigationTitle("Tasks List") // Set the navigation title for the list of tasks
                    }

                    // Button to navigate to AddUserView for adding a new task
                    NavigationLink(destination: AddUserView(viewModel: taskModel)) {
                        Image(systemName: "plus")
                            .font(.title.weight(.semibold)) // Plus icon with bold weight
                            .padding()
                            .background(Color("CustomColors")) // Custom background color for the button
                            .foregroundColor(.white)
                            .clipShape(Circle()) // Circular button shape
                    }
                }

                // Sort button to trigger sorting of tasks
                Button("Sort") {
                    taskModel.sortTasks()  // Sort the tasks in the task model
                }
                .frame(width: 150)
                .padding()
                .background(Color("CustomColors"))  // Custom background color for the button
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .toolbar {
                // Toolbar with Edit button on the top right of the navigation bar
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                        .foregroundColor(Color("CustomColors")) // Custom color for the Edit button
                }

                // Toolbar with a Toggle button for Dark Mode on the top left of the navigation bar
                ToolbarItem(placement: .navigationBarLeading) {
                    Toggle("Enable Dark Mode", isOn: $isDarkMode)  // Toggle to enable or disable Dark Mode
                        .accentColor(Color("CustomColors"))  // Custom color for the toggle switch
                        .padding()  
                }
            }
            .scrollContentBackground(.hidden) // Hide the background behind the scroll view
            .padding() // Add padding around the entire content view
            .preferredColorScheme(isDarkMode ? .dark : .light) // Set the color scheme based on the Dark Mode toggle
        }
    }
}

#Preview {
    ContentView()
}
